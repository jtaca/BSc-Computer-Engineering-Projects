package client;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import classes_partilhadas.Noticia;
import classes_partilhadas.TituloDeNoticia;
import client_interfaces.GUI_Interface;


public class GUI implements GUI_Interface{
	
	private JFrame frame = new JFrame("Googa-lhe");
	private JTextField textField = new JTextField(40);
	private DefaultListModel<TituloDeNoticia> listModel = new DefaultListModel<TituloDeNoticia>();
	private JList<TituloDeNoticia> listField = new JList<TituloDeNoticia>(listModel);
	private JTextPane textArea = new JTextPane();
	JButton searchButton;
	
	private Client client;
	
	private static final int DEFAULT_DIMENSIONS = 400;
	
	public GUI(Client cliente) {
		
		this.client = cliente;
		
		// para que o botao de fechar a janela termine a aplicacao
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
		frame.addWindowListener(new WindowListener() {
			
			@Override
			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowClosing(WindowEvent e) {
				client.close();
			}
			
			@Override
			public void windowClosed(WindowEvent e) {
			}
			
			@Override
			public void windowActivated(WindowEvent e) {
			}
		});
		
		// conteudo em sequencia da esquerda para a direita
		frame.setLayout(new BorderLayout());
		
		addFrameContent();
		
		// para que a janela se redimensione de forma a ter todo o seu conteudo visivel
		frame.pack();
	}
	
	private void addFrameContent() {
		
		JPanel northPanel = new JPanel();
		northPanel.setLayout(new FlowLayout());
		frame.add(northPanel, BorderLayout.NORTH);
		
		northPanel.add(textField);
		
		searchButton = new JButton("Search");
		northPanel.add(searchButton);
		searchButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				search();
			}
		});
		
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new FlowLayout());
		frame.add(centerPanel, BorderLayout.CENTER);
		
		centerPanel.add(listField);
		listField.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if(!e.getValueIsAdjusting() && !listField.isSelectionEmpty()) {
					TituloDeNoticia selectedValue = listField.getSelectedValue();
					client.requestNews(selectedValue.getTitulo());
				}
			}
		});
		
		JScrollPane scrollListField = new JScrollPane(listField);
		scrollListField.setPreferredSize(new Dimension(DEFAULT_DIMENSIONS, DEFAULT_DIMENSIONS));
		centerPanel.add(scrollListField);
		
		textArea.setEditable(false);
		textArea.setContentType("text/html");
		textArea.setPreferredSize(new Dimension(DEFAULT_DIMENSIONS, DEFAULT_DIMENSIONS));
		
		JScrollPane scrollArea = new JScrollPane(textArea);
		centerPanel.add(scrollArea);
		
	}
	
	@Override
	public synchronized void writeOnTextArea(Noticia content) {
		textArea.setText(content.toString());
		textArea.setCaretPosition(0);
	}
	
	@Override
	public synchronized void writeOnTextArea(String content) {
		textArea.setText(content);
		textArea.setCaretPosition(0);
	}
	
	private void search() {
		if(client.isConnected()) {
			String text = textField.getText();
			if(!text.equals("") && !text.equals(" ")) {
				disableButton();
				listField.clearSelection();
				textArea.setText("");
				client.requestSearchOfWord(text);
			} else {
				System.out.println("Please insert a word");
			}
		}
	}
	
	public void enableButton() {
		searchButton.setEnabled(true);
	}
	
	public void disableButton() {
		searchButton.setEnabled(false);
	}
	
	@Override
	public synchronized void refresh(TituloDeNoticia[] titulos) {
		if(titulos != null) {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					listModel.clear();
					listField.setListData(titulos);
					enableButton();
				}
			});
			 
			System.out.println(listField.getModel().toString());
		}
	}

	public synchronized void clearList() {
		listField.clearSelection();
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				listModel.clear();
				listField.setListData(new TituloDeNoticia[0]);
			}
		});
	}
	
	@Override
	public void open() {
		frame.setVisible(true);
	}
	
}
