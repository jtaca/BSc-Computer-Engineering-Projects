package client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.List;

import classes_partilhadas.Connections;
import classes_partilhadas.Noticia;
import classes_partilhadas.TipoDeMensagem;
import classes_partilhadas.TituloDeNoticia;
import client_interfaces.Client_Interface;
import classes_partilhadas.Message;

public class Client implements Client_Interface {
	
	private GUI userGUI;
	private Socket socket;
	private ObjectOutputStream out;
	private ClientConnection clientConnection;
	private boolean notConnected;
	private boolean firstTimeRunning;
	
	private String IP;
	
	private String word;
	
	private long startTime;
	
	public Client(String IP) {
		userGUI = new GUI(this);
		firstTimeRunning = true;
		word = null;
		this.IP = IP;
	}
	
	public static void main(String[] args) {
		String IP = null;
		if(args.length >= 1) {
			System.out.println(args[0]);
			IP = args[0];
		}
		new Client(IP).start();
	}
	
	public void start() {
		userGUI.open();
		runClient();
	}
	
	public void runClient() {
		notConnected = true;
		userGUI.clearList();
		userGUI.writeOnTextArea("OFFLINE");
		userGUI.disableButton();
		while(notConnected) {
			
			try {
				if(!firstTimeRunning)
					Thread.sleep(1000);
				connectToServer();
	
			} catch(IOException | InterruptedException e) {
				
			}
		}
		userGUI.writeOnTextArea("");
		userGUI.enableButton();
	}
	
	private void connectToServer() throws IOException {
		InetAddress endereco = InetAddress.getByName(IP);
		System.out.println("Endere�o = " + endereco);
		socket = new Socket(endereco, Connections.PORTO);
		
		System.out.println("Socket = " + socket);
		
		if(socket != null) {
			
			out = new ObjectOutputStream(socket.getOutputStream());
			
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
			
			clientConnection = new ClientConnection(in, this);
			clientConnection.start();
			
			out.writeObject(new Message<String>(TipoDeMensagem.ENTER_CLIENT, ""));
			
			notConnected = false;
		}
		if(firstTimeRunning)
			firstTimeRunning = false;
		
	}
	
	private void sendMessage(TipoDeMensagem tipo, String message) {
		try {
			out.writeObject(new Message<String>(tipo, message));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void addNewsListToRefresh(List<TituloDeNoticia> titulos) {
		titulos.sort(new NumberOfOccurrencesSort());
		TituloDeNoticia[] t = turnListIntoArray(titulos);
		userGUI.refresh(t);
	}
	
	public static TituloDeNoticia[] turnListIntoArray(List<TituloDeNoticia> titulos) {
		TituloDeNoticia[] t = new TituloDeNoticia[titulos.size()];
		int i = 0;
		for(TituloDeNoticia titulo : titulos) {
			t[i] = titulo;
			i++;
		}
		return t;
	}

	@Override
	public void requestNews(String title) {
		sendMessage(TipoDeMensagem.GET_NEWS, title);
	}
	
	@Override
	public void requestSearchOfWord(String word) {
		startTime = System.nanoTime();
		this.word = word;
		sendMessage(TipoDeMensagem.SEARCH_WORD, word);
	}
	
	@Override
	public void writeNewsOnTextArea(Noticia content) {
		userGUI.writeOnTextArea(content);
	}
	
	public void close() {
		if(isConnected()) {
			try {
				System.out.println("a fechar...");
				out.writeObject(new Message<String>(TipoDeMensagem.EXIT, ""));
				clientConnection.join(1000); // Join com timeout pode ser uma solucao para problemas futuros (Pode ser removido (Maybe))
				socket.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
	}
	
	public long getStartTime() {
		return startTime;
	}

	public boolean isConnected() {
		return !notConnected;
	}
	
	public String getWord() {
		return word;
	}
	
	
	
}
