package client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.SocketException;
import java.util.List;

import classes_partilhadas.Noticia;
import classes_partilhadas.TituloDeNoticia;
import interfaces_partilhadas.Message_Interface;

public class ClientConnection extends Thread {

	private ObjectInputStream in;
	private Client client;
	
	public ClientConnection(ObjectInputStream in, Client client) {
		this.in = in;
		this.client = client;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public void run() {
		boolean socketException = false;
		boolean error = false;
		Message_Interface obj;
		while(true) {	
			try {
				obj = (Message_Interface) in.readObject();
				if(obj.getTipo().name().equals("EXIT"))
					break;
				treatMessage(obj);
				
			} catch (SocketException e) {
				error = true;
				socketException = true;
			} catch (IOException e) {
				error = true;
			} catch (ClassNotFoundException e) {
				error = true;
				e.printStackTrace();
			} finally {
				if(error) {
					if(socketException) {
						client.runClient();
					}
					break;
				}
			}
		}
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void treatMessage(Message_Interface obj) {
		switch (obj.getTipo()) {
		case SEARCH_WORD:
			client.addNewsListToRefresh((List<TituloDeNoticia>) obj.getContent());
			long endTime = System.nanoTime();

			long duration = (endTime - client.getStartTime())/1000000;  //divide by 1000000 to get milliseconds.
			System.out.println("Duration of load " + duration + " milliseconds");
			break;
			
		case GET_NEWS:
			client.writeNewsOnTextArea((Noticia) obj.getContent());
			break;


		default:
			break;
		}
		
	}
	
	
}
