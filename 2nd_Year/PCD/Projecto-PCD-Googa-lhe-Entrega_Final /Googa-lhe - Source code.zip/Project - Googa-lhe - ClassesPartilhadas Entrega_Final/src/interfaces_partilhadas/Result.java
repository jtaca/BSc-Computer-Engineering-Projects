package interfaces_partilhadas;

public interface Result<E> {
	
	public E getID();
	
}
