package classes_partilhadas;

public enum TipoDeMensagem {
	ENTER_CLIENT, SEARCH_WORD, GET_NEWS, ENTER_WORKER, SEND_TASK, GIVE_RESULT, EXIT;
}
