package classes_partilhadas;

public class Connections {
	
	public static final int PORTO = 8080;

}
