package classes_partilhadas;

import java.io.Serializable;

import classes_partilhadas.Noticia;
import interfaces_partilhadas.Result;

public class Task implements Serializable, Result<Integer> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1795153527222860218L;
	
	transient private int id;
	private String word;
	private Noticia noticia;
	
	public Task(int id, String word, Noticia noticia) {
		this.id = id;
		this.word = word;
		this.noticia = noticia;
	}
	
	public Integer getID() {
		return id;
	}
	
	public String getWord() {
		return word;
	}
	
	public Noticia getNoticia() {
		return noticia;
	}
	
}
